chmod +x iniminer-cuda-linux-x64
./iniminer-cuda-linux-x64 --pool $POOL_URL --cuda --retry-delay 5 --farm-retries 99
